%% clean up
clc; clear; close all;

%% Input parameters:
MAX_ITER = 100;
STEP_TOL = 2e-5;
procNum = 12;

% Interpolation parameter:
Ia = 1e+0;

% Geometry of physical and design space: 
LX  = 20;
LSX = 8;
LDX = 4;
LY  = 20;
LSY = 9.5;
LDY = 1;

% Initial guess:
Vol_design = LDX * LDY;  Vol_target = (1/2)^2*pi;
charact_length = sqrt(Vol_target);
delta_X =   0.75 * charact_length;
delta_Y =   0.75 * charact_length;

XC = LSX + LDX/2;
YC = LSY + LDY/2;

% Target volume ratio (within design space):
global TVR; TVR = Vol_target/Vol_design;

%% MMA files path
addpath('MMA_files');

%% Pre-processing steps:
system("foamCleanTutorials");
system("blockMesh");

% Create data folder, to save optimization results:
if not(isfolder('data'))
    mkdir('data')
end

% Runing preProc
system("preProc");

% Read extData.dat
fileID = fopen('data/extData.dat','r');
extData = fscanf(fileID, '%d'); fclose(fileID);

% number of cells
NC  = extData(1); 

% Read (cell centers) coordinates from data/coord.dat
fileID = fopen('data/coords.dat','r');
cellCentCoords = fscanf(fileID, '%f', [3 Inf]); fclose(fileID);

%% Create X0, and initialize it:
X0 = zeros(NC, 1);
for i=1:NC
    x = cellCentCoords(1, i);
    y = cellCentCoords(2, i);
    if(abs(x-XC) <= delta_X/2 && abs(y-YC) <= delta_Y/2)
        X0(i) = 1;
    end
end

%% Setting up design variables:
x_span = LSX + [0 LDX]; 
y_span = LSY + [0 LDY];
freeIDm = 0; dummy_iter = 1;
for i=1:NC
    x = cellCentCoords(1, i);
    y = cellCentCoords(2, i);
    if(x >= x_span(1) && x <= x_span(2) && y >= y_span(1) && y <= y_span(2))
        freeIDm(dummy_iter) = i;
        dummy_iter = dummy_iter + 1;
    end    
end

% Number of design variables (inside design space):
ND = length(freeIDm);

% All design variables:
X = X0;

%% Optimization part:

% MMA parameters:
n = ND;
m = 1;
xval    = X0(freeIDm);
xold1   = xval; xold2   = xval;
xmin    = zeros(n, 1);
xmax    = ones(n, 1);
low     = xmin;  upp     = xmax;
c       = 1000; d       = 1; a0      = 1; a       = 0;

% Time (folder) control parameter:
lastTimeName(1) = 0;

% provide X for Openfoam in lastest time folder 
X(freeIDm) = Intrp(xval, Ia);
writematrix(X, '0/X.dat');

% start parallel solve
system("decomposePar -latestTime");
system(join(["mpirun -np " num2str(procNum) " primalSol -parallel"]));
system("reconstructPar -latestTime");
system("rm -rf processor*");

% update last time (must be after solve step)
fileID = fopen('data/cTime.dat','r');
lastTimeName(2) = fscanf(fileID, '%d'); fclose(fileID);

% compute adjoint/sensitivities
system("adjointSens");

% read Obj and DObj_Dgma
fileID       = fopen([num2str(lastTimeName(2)) , '/Fx.dat'],'r');
Obj(1)       = fscanf(fileID, '%f'); fclose(fileID);
fileID       = fopen([num2str(lastTimeName(2)) , '/DFx_Dgma.dat'],'r');
DObj_Dgma    = fscanf(fileID, '%f'); fclose(fileID);

f0val = Obj(1);
df0dx = DObj_Dgma(freeIDm) .* DX_Dxval(xval, Ia);
[fval, dfdx] = VolC(xval);

iter = 1; Tol(1) = 1.0;
Const_1(1) = fval; volRatio(1) = sum(xval)/length(xval);
[CS_X(1), CS_Y(1)] = GEOM(X, cellCentCoords);
while iter < MAX_ITER && Tol(iter) > STEP_TOL
    
    [xmma, ~, ~, ~, ~, ~, ~, ~, ~, low, upp] = ...
    mmasub(m, n, iter, xval, xmin, xmax, xold1, xold2, ...
    f0val, df0dx, fval, dfdx, low,upp ,a0, a, c, d);
    xold2 = xold1;  xold1 = xval;  xval  = xmma;
    
    %%% primal solve & sensitivity:
    X(freeIDm) = Intrp(xval, Ia);
    writematrix(X,  [num2str(lastTimeName(iter+1)) , '/X.dat']);

    % start parallel solve
    system("decomposePar -latestTime");
    system(join(["mpirun -np " num2str(procNum) " primalSol -parallel"]));    
    system("reconstructPar -latestTime");
    system("rm -rf processor*");

    % update last time (must be after solve step)
    fileID = fopen('data/cTime.dat','r');
    lastTimeName(iter+2) = fscanf(fileID, '%d'); fclose(fileID);

    % compute adjoint/sensitivities
    system("adjointSens");

    % read Obj and DObj_Dgma
    fileID = fopen([num2str(lastTimeName(iter+2)) , '/Fx.dat'],'r');
    Obj(iter+1) = fscanf(fileID, '%f'); fclose(fileID);
    fileID = fopen([num2str(lastTimeName(iter+2)) , '/DFx_Dgma.dat'],'r');
    DObj_Dgma = fscanf(fileID, '%f'); fclose(fileID);

    f0val = Obj(iter+1);
    df0dx = DObj_Dgma(freeIDm) .* DX_Dxval(xval, Ia);
    [fval, dfdx] = VolC(xval);

    Const_1(iter+1) = fval;
    volRatio(iter+1) = sum(xval)/length(xval);
    [CS_X(iter+1), CS_Y(iter+1)] = GEOM(X, cellCentCoords);
    Tol(iter+1) = max(abs(xold1-xval));
    iter = iter+1;

    fprintf('+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++\n')
    fprintf('Iteration: %d, Obj: %4.8f,  VolC: %4.8f, Tol: %4.8f \n\n', iter, f0val, fval, max(abs(xold1-xval)))
    fprintf('+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++\n')
    
    writematrix([(1:length(Obj))' , Obj', Const_1', volRatio', CS_X', CS_Y', Tol'], 'data/optim_hist.dat', 'Delimiter', ',');
end

%% ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~FUNCTIONS:
%% volume constraint ++++++++++++++++++++++++++++++++++++++++++++++++++++++
function [C, dC] = VolC(xval)
    global TVR;
    
    Vol = sum(xval);
    Vol_max = length(xval);
    Vol_min = TVR * Vol_max;    
    C  =  1.0 - Vol/Vol_min;
    dC = -1 * (ones(1, length(xval))/Vol_min);
end

%% Length and thickness +++++++++++++++++++++++++++++++++++++++++++++++++++
function [CS_X, CS_Y] = GEOM(X, cellCentCoords)
    xmin = +Inf;  xmax = -Inf;
    ymin = +Inf;  ymax = -Inf;

    for i=1:length(X)
        x = cellCentCoords(1, i);
        y = cellCentCoords(2, i);
        if(X(i) > 0.5)
            if(x < xmin)
                xmin = x;
            end
            if(x > xmax)
                xmax = x;
            end
            if(y < ymin)
                ymin = y;
            end
            if(y > ymax)
                ymax = y;
            end
        end    
    end
    
    CS_X = xmax - xmin;
    CS_Y = ymax - ymin;
end

%% Interpolation function +++++++++++++++++++++++++++++++++++++++++++++++++
%~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
function [X] = Intrp(xval, q)
%~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
a = xval;
b = 1+q-q*xval;
X = a./b;
end

%% Interpolation function derivative ++++++++++++++++++++++++++++++++++++++
%~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
function [S] = DX_Dxval(xval, q)
%~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
a = 1+q;
b = 1+q-q*xval;
c = b.^2;
S = a./c;
end
