procNum = 12;
maxNumCompThreads(procNum);

fprintf("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ reading files:\n");
Vec_R_src_C   = fread(fopen("data/Vec_R_src_C.bin"),'double');
Vals_bin      = fread(fopen("data/VAL.bin"),'double');
I_index_bin   = fread(fopen("data/I.bin"),'int');
J_index_bin   = fread(fopen("data/J.bin"),'int');
Mat_R_bin     = sparse(I_index_bin+1, J_index_bin+1, Vals_bin);

fprintf("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ solving adjoint:\n");
Lambda_C = Mat_R_bin\Vec_R_src_C;

fprintf("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ writing files:\n");
fileID = fopen('data/Lambda_J.bin','w');
fwrite(fileID, 0.0*Lambda_C, 'double');
fclose(fileID);

fileID = fopen('data/Lambda_C.bin','w');
fwrite(fileID, Lambda_C, 'double');
fclose(fileID);
fprintf("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ end of adjoint solve ...\n");






