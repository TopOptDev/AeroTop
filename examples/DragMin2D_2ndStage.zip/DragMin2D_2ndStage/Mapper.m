clc; clear all; close all;

%% Perform mapping
system("foamCleanTutorials");
system("rm 0/*");
system("blockMesh");
%% ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ Modify root case:
% use 'interpolate' or 'mapNearest' or 'cellPointInterpolate'
system("mapFields -consistent -sourceTime 'latestTime' -mapMethod 'interpolate' ../DragMin2D/");

%% reading mapped gamma
fid = fopen('0/gamma');
while 1
    Line = fgetl(fid);
    
    if isempty(Line) == 1
        continue;
    end
    
    if Line(1) == 'i'
        N = str2double(fgetl(fid));
        break;
    end       
end

Xi = zeros(N, 1);
fgetl(fid); % to skip ')'

for i = 1:N
    Xi(i) = str2double(fgetl(fid));
end

%% writing mapped gamma to Xi,dat
writematrix(Xi, '0/Xi.dat');
