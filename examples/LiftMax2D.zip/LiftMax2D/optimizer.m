%% clean up
clc; clear; close all;

%% UDF parameters:
MAX_ITER = 100;
STEP_TOL = 1e-5;

global F_star;
F_star = 20;

beta_J = 10.0;
beta_C = 1.0;

% Interp a
Ia = 0.1;

LX = 12;
LY = 12;

LSX = 3;
LDX = 5.5;

LSY = 5.5;
LDY = 1.5;

XC = LSX + 1.25;
YC = LSY + LDY - 0.25;

Vol_design = LDX * LDY;   
Vol_target = (1/2)^2*pi;
charact_length = sqrt(Vol_target);

% initial rectangular shape params:
delta_X =   0.2 * charact_length;
delta_Y =   0.2 * charact_length;

% target_volume_ratio: a circle fitted in Design space
global TVR; TVR = Vol_target/Vol_design;
%% MMA files path
addpath('MMA_files');

%% Pre-processing steps:
system("foamCleanTutorials");
system("blockMesh");

% Create data folder, to save optimization results:
if not(isfolder('data'))
    mkdir('data')
end

% Runing preProc
system("preProc");

% Read extData.dat
fileID = fopen('data/extData.dat','r');
extData = fscanf(fileID, '%d'); fclose(fileID);

% #cells, #faces, #internalFaces 
NC  = extData(1); %NF  = extData(2); NFi = extData(3);

% Read (cell centers) coordinates from data/coord.dat
fileID = fopen('data/coords.dat','r');
cellCentCoords = fscanf(fileID, '%f', [3 Inf]); fclose(fileID);

%% Create X0, and initialize it:
X0 = zeros(NC, 1);
for i=1:NC
    x = cellCentCoords(1, i);
    y = cellCentCoords(2, i);
    if(abs(x-XC) <= delta_X/2 && abs(y-YC) <= delta_Y/2)
        X0(i) = 1;
    end
end

%% Setting up design variables:
x_span = LSX + [0 LDX]; 
y_span = LSY + [0 LDY];
freeIDm = 0; dummy_iter = 1;
for i=1:NC
    x = cellCentCoords(1, i);
    y = cellCentCoords(2, i);
    if(x >= x_span(1) && x <= x_span(2) && y >= y_span(1) && y <= y_span(2))
        freeIDm(dummy_iter) = i;
        dummy_iter = dummy_iter + 1;
    end    
end

% Number of design variables (inside design space):
ND = length(freeIDm);

% All design variables:
X = X0;

%% Optimization part:

% MMA parameters:
n = ND;
m = 2;
xval    = X0(freeIDm);
xold1   = xval; xold2   = xval;
xmin    = zeros(n, 1); %0.999*X0(freeIDm);
xmax    = ones(n, 1);
low     = xmin;  upp     = xmax;
c       = [1000  1000]';
d       = [1  1]';
a0      = 1;
a       = [0  0]';



% Time (folder) control parameter:
lastTimeName(1) = 0;

%%% primal solve & sensitivity:
% provide X for Openfoam in lastest time folder 
X(freeIDm) = Intrp(xval, Ia);
writematrix(X, '0/X.dat');

% start parallel solve
system("decomposePar -latestTime");
system("mpirun -np 12 primalSol -parallel");    
system("reconstructPar -latestTime");
system("rm -rf processor*");

% update last time (must be after solve step)
fileID = fopen('data/cTime.dat','r');
lastTimeName(2) = fscanf(fileID, '%d'); fclose(fileID);

% compute adjoint/sensitivities
system("adjointSens");

% read Obj/Const and DObj_Dgma/DConst_Dgma
fileID       = fopen([num2str(lastTimeName(2)) , '/Fy.dat'],'r');
Obj(1)       = fscanf(fileID, '%f'); fclose(fileID);
fileID       = fopen([num2str(lastTimeName(2)) , '/DFy_Dgma.dat'],'r');
DObj_Dgma    = fscanf(fileID, '%f'); fclose(fileID);
fileID       = fopen([num2str(lastTimeName(2)) , '/Fx.dat'],'r');
Const(1)     = fscanf(fileID, '%f'); fclose(fileID);
fileID       = fopen([num2str(lastTimeName(2)) , '/DFx_Dgma.dat'],'r');
DConst_Dgma  = fscanf(fileID, '%f'); fclose(fileID);

f0val = beta_J*F_star - Obj(1);
df0dx = -1.0 * DObj_Dgma(freeIDm) .* DX_Dxval(xval, Ia);
fval = Const(1) - beta_C*F_star;
dfdx = DConst_Dgma(freeIDm)' .* DX_Dxval(xval, Ia)';
[VC, dVC] = VolC(xval);
fval(2) = VC;
dfdx(2, :) = dVC;

iter = 1; Tol(1) = 1.0;
Const_1(1) = fval(1); volRatio(1) = sum(xval)/length(xval);
[CS_X(1), CS_Y(1)] = GEOM(X, cellCentCoords);
while iter < MAX_ITER && Tol(iter) > STEP_TOL
    
    [xmma, ~, ~, ~, ~, ~, ~, ~, ~, low, upp] = ...
    mmasub(m, n, iter, xval, xmin, xmax, xold1, xold2, ...
    f0val, df0dx, fval', dfdx, low,upp ,a0, a, c, d);
    xold2 = xold1;  xold1 = xval;  xval  = xmma;
    
    %%% primal solve & sensitivity:
    X(freeIDm) = Intrp(xval, Ia);
    writematrix(X,  [num2str(lastTimeName(iter+1)) , '/X.dat']);

    % start parallel solve
    system("decomposePar -latestTime");
    system("mpirun -np 12 primalSol -parallel");    
    system("reconstructPar -latestTime");
    system("rm -rf processor*");

    % update last time (must be after solve step)
    fileID = fopen('data/cTime.dat','r');
    lastTimeName(iter+2) = fscanf(fileID, '%d'); fclose(fileID);

    % compute adjoint/sensitivities (will provide DO_Dgma in last folder)
    system("adjointSens");

    % read Obj/Const and DObj_Dgma/DConst_Dgma
    fileID = fopen([num2str(lastTimeName(iter+2)) , '/Fy.dat'],'r');
    Obj(iter+1) = fscanf(fileID, '%f'); fclose(fileID);
    fileID = fopen([num2str(lastTimeName(iter+2)) , '/DFy_Dgma.dat'],'r');
    DObj_Dgma = fscanf(fileID, '%f'); fclose(fileID);

    fileID       = fopen([num2str(lastTimeName(iter+2)) , '/Fx.dat'],'r');
    Const(iter+1)     = fscanf(fileID, '%f'); fclose(fileID);
    fileID       = fopen([num2str(lastTimeName(iter+2)) , '/DFx_Dgma.dat'],'r');
    DConst_Dgma  = fscanf(fileID, '%f'); fclose(fileID);
    
    f0val = beta_J*F_star - Obj(iter+1);
    df0dx = -1.0 * DObj_Dgma(freeIDm) .* DX_Dxval(xval, Ia);
    fval = Const(iter+1) - beta_C*F_star;
    dfdx = DConst_Dgma(freeIDm)' .* DX_Dxval(xval, Ia)';    
    [VC, dVC] = VolC(xval);
    fval(2) = VC;
    dfdx(2, :) = dVC;

    Const_1(iter+1) = fval(1);
    volRatio(iter+1) = sum(xval)/length(xval);
    [CS_X(iter+1), CS_Y(iter+1)] = GEOM(X, cellCentCoords);
    Tol(iter+1) = max(abs(xold1-xval));
    iter = iter+1;

    fprintf('+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++\n')
    fprintf('Iteration: %d, Obj: %4.8f,  VolC: %4.8f, Tol: %4.8f \n\n', iter, f0val, fval, max(abs(xold1-xval)))
    fprintf('+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++\n')
    
    writematrix([(1:length(Obj))' , Obj', Const_1', volRatio', CS_X', CS_Y', Tol'], 'data/optim_hist.dat', 'Delimiter', ',');
end

%% Length and thickness
function [CS_X, CS_Y] = GEOM(X, cellCentCoords)
    xmin = +Inf;  xmax = -Inf;
    ymin = +Inf;  ymax = -Inf;

    for i=1:length(X)
        x = cellCentCoords(1, i);
        y = cellCentCoords(2, i);
        if(X(i) > 0.5)
            if(x < xmin)
                xmin = x;
            end
            if(x > xmax)
                xmax = x;
            end
            if(y < ymin)
                ymin = y;
            end
            if(y > ymax)
                ymax = y;
            end
        end    
    end
    
    CS_X = xmax - xmin;
    CS_Y = ymax - ymin;
end

%% Interpolation ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
%~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
function [X] = Intrp(xval, q)
%~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
a = xval;
b = 1+q-q*xval;
X = a./b;
end

%~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
function [S] = DX_Dxval(xval, q)
%~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
a = 1+q;
b = 1+q-q*xval;
c = b.^2;
S = a./c;
end

%% Volume constraint
function [C, dC] = VolC(xval)
    global TVR;
    
    Vol = sum(xval);
    Vol_max = length(xval);
    Vol_min = TVR * Vol_max;
    
    C  =  1.0 - Vol/Vol_min;
    dC = -1 * (ones(1, length(xval))/Vol_min);
end
